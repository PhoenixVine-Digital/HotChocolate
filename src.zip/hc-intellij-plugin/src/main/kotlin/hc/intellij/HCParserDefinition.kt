package hc.intellij

import com.intellij.extapi.psi.PsiFileBase
import com.intellij.lang.ASTNode
import com.intellij.lang.ParserDefinition
import com.intellij.lang.PsiParser
import com.intellij.lexer.Lexer
import com.intellij.openapi.fileTypes.FileType
import com.intellij.openapi.project.Project
import com.intellij.psi.FileViewProvider
import com.intellij.psi.PsiElement
import com.intellij.psi.tree.IFileElementType
import com.intellij.psi.tree.TokenSet

val HC_FILE = IFileElementType(HCLanguage)

// `ASTWrapperPsiElement`'s own `getReferences()` does NOT route through
// `ReferenceProvidersRegistry` by default (an IntelliJ Platform default, not specific to this
// SDK version) -- `HCReferences.kt`'s `HCReferenceContributor` registers providers for several
// composite node types (`REF_EXPR`/`TYPE_REF`/...), but without this override,
// `PsiFile.findReferenceAt`/`getReferenceAtCaretPosition`/Ctrl+B all come back empty even though
// `ReferenceProvidersRegistry.getReferencesFromProviders(element)` finds the registered reference
// just fine when called directly -- found via a throwaway debug test (see `HCReferences.kt`'s own
// header for the full story).
private class HCCompositeElement(node: ASTNode) : com.intellij.extapi.psi.ASTWrapperPsiElement(node) {
    override fun getReferences(): Array<com.intellij.psi.PsiReference> =
        com.intellij.psi.impl.source.resolve.reference.ReferenceProvidersRegistry.getReferencesFromProviders(this)
}

class HCFile(viewProvider: FileViewProvider) : PsiFileBase(viewProvider, HCLanguage) {
    override fun getFileType(): FileType = HCFileType
    override fun toString(): String = "HotChocolate File"
}

class HCParserDefinition : ParserDefinition {
    override fun createLexer(project: Project?): Lexer = HCLexer()
    override fun createParser(project: Project?): PsiParser = HCPsiParser
    override fun getFileNodeType() = HC_FILE
    override fun getWhitespaceTokens(): TokenSet = TokenSet.create(com.intellij.psi.TokenType.WHITE_SPACE)
    override fun getCommentTokens(): TokenSet = TokenSet.create(HCTokenTypes.LINE_COMMENT, HCTokenTypes.DOC_COMMENT)
    override fun getStringLiteralElements(): TokenSet = TokenSet.create(
        HCTokenTypes.STRING, HCTokenTypes.ISTRING_BEGIN, HCTokenTypes.ISTRING_PART, HCTokenTypes.ISTRING_END,
    )
    override fun createElement(node: ASTNode): PsiElement = HCCompositeElement(node)
    override fun createFile(viewProvider: FileViewProvider): com.intellij.psi.PsiFile = HCFile(viewProvider)
}

package hc.intellij

import com.intellij.lang.annotation.AnnotationHolder
import com.intellij.lang.annotation.Annotator
import com.intellij.lang.annotation.HighlightSeverity
import com.intellij.psi.PsiElement
import com.intellij.psi.PsiFile
import com.intellij.psi.PsiWhiteSpace
import com.intellij.psi.util.PsiTreeUtil

// The first real SEMANTIC checks (not just syntax) -- "errors soon," now partially arrived. Four
// checks, each deliberately scoped to what's verifiable off `HCPsiParser`'s real tree alone,
// without needing actual TYPE inference (that's the next, much bigger, follow-up):
// 1. `@` annotation/directive validation -- mirrors the real compiler's own `leadingMarkers()`
//    (see `Parser.kt`'s own error strings, copied verbatim below so a user sees the SAME message
//    in the IDE as they would from a real `hc build`) -- an unrecognized directive, or one used
//    before the wrong declaration kind.
// 2. `break`/`continue` outside any enclosing loop.
// 3. Duplicate top-level declaration names, scoped per-kind (`Duplicate function`/`struct`/
//    `enum`/`interface`/`extern class`, matching the real compiler's own message text) plus the
//    real compiler's own cross-kind rule: an enum variant's name shares a namespace with plain
//    struct names (`StructLit`/`variant` construction sites are otherwise ambiguous).
// 4. Undefined references -- a bare `REF_EXPR` (see `HCPsiParser.identLed`'s own header for
//    exactly which shapes become `REF_EXPR` vs. something else entirely -- `a.b.c`'s `b`/`c`,
//    `Type::method`'s `Type`, and a struct literal's own field names are all PLAIN LEAF tokens
//    under a different node, never `REF_EXPR`, so this check is already naturally scoped to real
//    value references without needing to special-case any of them) that doesn't resolve to
//    anything in scope -- see `collectLocalNames`'s own header for the deliberately conservative,
//    over-inclusive resolution rule this uses to stay FALSE-POSITIVE-safe without real type
//    inference or true block scoping.
//
// Called once per `PsiElement` in the tree (bottom-up, not once per file) -- each check below is
// keyed on the specific node kind(s) it cares about and is a no-op for everything else. Checks
// 3/4 additionally only do real work once, at the file root (`element is PsiFile`), since both
// need whole-file context (every top-level name; every `FN_DECL`'s own local names) rather than
// being meaningfully checkable one node at a time.
class HCAnnotator : Annotator {
    override fun annotate(element: PsiElement, holder: AnnotationHolder) {
        when (element.node?.elementType) {
            HCElementTypes.ANNOTATION -> checkAnnotation(element, holder)
            HCElementTypes.BREAK_STMT -> checkLoopControl(element, holder, "break")
            HCElementTypes.CONTINUE_STMT -> checkLoopControl(element, holder, "continue")
            else -> {}
        }
        if (element is PsiFile) {
            checkDuplicateTopLevelNames(element, holder)
            checkUndefinedReferences(element, holder)
            // Argument-count/basic-literal-type checks -- see `HCTypeChecks.kt`'s own header.
            checkArgCountsAndBasicTypes(element, holder)
        }
    }

    private fun directChildren(element: PsiElement): List<PsiElement> {
        val out = mutableListOf<PsiElement>()
        var c = element.firstChild
        while (c != null) {
            out.add(c)
            c = c.nextSibling
        }
        return out
    }

    private fun nextSignificantSibling(element: PsiElement): PsiElement? {
        var next = element.nextSibling
        while (next is PsiWhiteSpace) next = next.nextSibling
        return next
    }

    private fun error(holder: AnnotationHolder, anchor: PsiElement, message: String) {
        holder.newAnnotation(HighlightSeverity.ERROR, message).range(anchor).create()
    }

    // `@name` / `@"binary.Name"` -- children are `[AT, nameToken, (LPAREN ... RPAREN)?]`, see
    // `HCPsiParser.leadingAnnotations`.
    private fun checkAnnotation(element: PsiElement, holder: AnnotationHolder) {
        val nameToken = directChildren(element).getOrNull(1) ?: return
        val isString = nameToken.node?.elementType == HCTokenTypes.STRING
        val kind = when {
            isString -> "string"
            nameToken.text == "must_use" -> "must_use"
            nameToken.text == "serializable" -> "serializable"
            nameToken.text == "entry" -> "entry"
            nameToken.text == "dev" -> "dev"
            else -> null
        }
        if (kind == null) {
            error(
                holder, element,
                "expected a quoted annotation name (@\"binary.Name\") or a known compiler directive " +
                    "(@serializable, @must_use, @dev, @entry(\"target\", ...)) after '@'",
            )
            return
        }

        if (element.parent?.node?.elementType == HCElementTypes.IMPL_DECL) {
            if (kind != "must_use") error(holder, element, "only '@must_use' is supported before an impl method")
            return
        }

        val next = nextSignificantSibling(element)
        val nextType = next?.node?.elementType
        val isFn = nextType == HCElementTypes.FN_DECL
        val isStruct = nextType == HCElementTypes.STRUCT_DECL
        when (kind) {
            "serializable" -> if (!isStruct) error(holder, element, "'@serializable' can only precede a top-level 'struct'")
            "must_use" -> if (!isFn) error(holder, element, "'@must_use' can only precede a top-level 'fn'")
            "dev" -> if (!isFn) error(holder, element, "'@dev' can only precede a top-level 'fn'")
            "entry" -> if (!isFn) error(holder, element, "'@entry(...)' can only precede a top-level 'fn'")
            "string" -> if (!isFn && !isStruct) error(holder, element, "annotations can only precede a top-level 'struct' or 'fn'")
        }
    }

    // Walks up parents looking for an enclosing `WHILE_STMT`/`FOR_STMT` -- stops at the nearest
    // `FN_DECL` (a `break`/`continue` never sees past its own function's boundary) or the file
    // root.
    private fun checkLoopControl(element: PsiElement, holder: AnnotationHolder, keyword: String) {
        var p: PsiElement? = element.parent
        while (p != null) {
            val t = p.node?.elementType
            if (t == HCElementTypes.WHILE_STMT || t == HCElementTypes.FOR_STMT) return
            if (t == HCElementTypes.FN_DECL || p is PsiFile) break
            p = p.parent
        }
        error(holder, element, "'$keyword' can only appear inside a loop")
    }

    private val DECL_KEYWORD_TO_KIND = mapOf(
        HCElementTypes.FN_DECL to "function",
        HCElementTypes.STRUCT_DECL to "struct",
        HCElementTypes.ENUM_DECL to "enum",
        HCElementTypes.INTERFACE_DECL to "interface",
        HCElementTypes.EXTERN_CLASS_DECL to "extern class",
    )

    private fun declaredName(decl: PsiElement): PsiElement? =
        directChildren(decl).firstOrNull { it.node?.elementType == HCTokenTypes.IDENT }

    private fun checkDuplicateTopLevelNames(file: PsiFile, holder: AnnotationHolder) {
        val seenByKind = mutableMapOf<String, MutableMap<String, PsiElement>>()
        // Enum variant names and plain struct names share ONE namespace (real compiler rule --
        // `Duplicate variant/struct name`, see this file's own header) -- tracked separately from
        // `seenByKind["struct"]` since the message differs and a struct/variant collision isn't
        // itself a same-kind duplicate.
        val structAndVariantNames = mutableMapOf<String, PsiElement>()

        for (decl in directChildren(file)) {
            val kind = DECL_KEYWORD_TO_KIND[decl.node?.elementType] ?: continue
            val nameToken = declaredName(decl) ?: continue
            val name = nameToken.text

            val bucket = seenByKind.getOrPut(kind) { mutableMapOf() }
            if (bucket.containsKey(name)) {
                error(holder, nameToken, "Duplicate $kind '$name'")
            } else {
                bucket[name] = nameToken
            }

            if (kind == "struct") {
                if (structAndVariantNames.containsKey(name)) {
                    error(
                        holder, nameToken,
                        "Duplicate variant/struct name '$name' (enum variant names share a namespace with structs and must be globally unique)",
                    )
                } else {
                    structAndVariantNames[name] = nameToken
                }
            }
            if (kind == "enum") {
                for (variant in directChildren(decl).filter { it.node?.elementType == HCElementTypes.ENUM_VARIANT }) {
                    val variantName = declaredName(variant) ?: continue
                    val vText = variantName.text
                    if (structAndVariantNames.containsKey(vText)) {
                        error(
                            holder, variantName,
                            "Duplicate variant/struct name '$vText' (enum variant names share a namespace with structs and must be globally unique)",
                        )
                    } else {
                        structAndVariantNames[vText] = variantName
                    }
                }
            }
        }
    }

    private fun elementsOfType(root: PsiElement, type: HCElementType): List<PsiElement> =
        PsiTreeUtil.collectElements(root) { it.node?.elementType == type }.toList()

    // Names that are real, callable/referenceable values in EVERY `.hc`/`.hotc` file regardless
    // of what that file itself declares -- none of these come from a `FnDecl`/`EnumDecl` this
    // file's own parser would ever see, so `collectTopLevelValueNames` genuinely cannot discover
    // them by walking the current file's tree. Two different reasons a name ends up here:
    // - `print`/`read_line` are real compiler INTRINSICS, special-cased directly in the real
    //   checker's own fn-type map (`Checker.kt`: `fnRetTypes = checker.fns... + ("print" to
    //   Ty.Unit_) + ("read_line" to Ty.Str_())`) rather than resolved from any declared `fn` at
    //   all.
    // - `vec_of`/`registry_new`/`read_int`/`read_string`/`read_ints`/`read_strings` are real
    //   PRELUDE functions (`Prelude.kt`'s `PRELUDE_SOURCE`), auto-merged into every program before
    //   the checker ever runs; `Some`/`None`/`Ok`/`Err` are the prelude's own `Option<T>`/
    //   `Result<T, E>` enum variants, included here too since a bare bit like `return None;` is a
    //   real, common shape and this check has no way to special-case "these enums came from the
    //   prelude" from ordinary enum-variant collection.
    // Missing an entry here is a REAL false-positive risk, not a cosmetic gap -- see
    // `HCAnnotatorTest`'s own real-example sweep, which is exactly what this list was built and
    // verified against.
    private val ALWAYS_KNOWN_VALUE_NAMES = setOf(
        "print", "read_line", "drop",
        "vec_of", "registry_new", "read_int", "read_string", "read_ints", "read_strings",
        "Some", "None", "Ok", "Err",
    )

    // Every name a value expression could legitimately refer to at the TOP level: a callable
    // `fn`, a bare (non-generic) enum variant (`Some`/`None`-shaped -- a generic enum's variants
    // need the qualified `Base<Arg>::Variant` form the real grammar requires, which parses as
    // `STATIC_CALL_EXPR`-adjacent territory, not a bare `REF_EXPR`, so they're never checked
    // against this set at all), and a top-level `static` constant. Struct/interface/extern-class
    // names themselves are deliberately NOT included -- a bare struct name alone isn't a
    // meaningful value (see `identLed`'s own header: it only ever appears as the lead of a
    // `StructLit`/`StaticCall`, never bare), so a real typo there should still surface as
    // "unresolved reference" rather than being silently accepted.
    //
    // Also collects from every SIBLING `.hc`/`.hotc` file in the SAME DIRECTORY -- real, not
    // hypothetical: the real compiler's own directory-mode compilation (`hc run <project-dir>`)
    // merges every `.hotc` file found into ONE flat program with one shared top-level namespace
    // (see `Main.kt`'s own `parseEntry` doc), which is exactly how `examples/multifile/`,
    // `examples/registries/`, and `examples/battle/` are laid out -- `main.hc` calling a `fn`
    // declared in a sibling file in the same folder is real, valid, already-working code, not a
    // typo. The IDE has no way to know which directory a given file is actually MEANT to be
    // compiled as part of (that's a `hc run`/`hc build` CLI argument, not anything in the file
    // itself), so "immediate containing directory" is a deliberate, disclosed heuristic -- it
    // matches every real multi-file example in this repo, but a project layout that spreads one
    // logical multi-file program across NESTED subdirectories wouldn't be picked up by this.
    private fun collectTopLevelValueNames(file: PsiFile): Set<String> {
        val names = mutableSetOf<String>()
        fun collectFrom(f: PsiFile) {
            for (decl in directChildren(f)) {
                when (decl.node?.elementType) {
                    HCElementTypes.FN_DECL, HCElementTypes.STATIC_DECL -> declaredName(decl)?.let { names += it.text }
                    HCElementTypes.ENUM_DECL -> for (variant in directChildren(decl).filter { it.node?.elementType == HCElementTypes.ENUM_VARIANT }) {
                        declaredName(variant)?.let { names += it.text }
                    }
                    else -> {}
                }
            }
        }
        collectFrom(file)
        file.containingDirectory?.files?.forEach { sibling ->
            if (sibling !== file && sibling.language == HCLanguage) collectFrom(sibling)
        }
        return names
    }

    // Every name LOCALLY bound anywhere inside one `FN_DECL` (top-level fn or impl method) --
    // flat and flow-insensitive (a name bound in one `if` branch is treated as visible in a
    // sibling branch too, and for the fn's ENTIRE body, not just after its own binding point).
    // Real, deliberate over-inclusion, not an oversight: getting true block-scoping/flow ordering
    // exactly right needs more structure than this pass tracks, and the failure mode of getting
    // it WRONG in the strict direction is a false "unresolved reference" on perfectly valid code
    // -- much worse for an IDE check than occasionally staying quiet on a real (and rare) same-
    // function shadowing/use-before-definition mistake, which the real compiler's own checker
    // will still catch at build time regardless. Binding sites covered: fn params (incl. `self`,
    // which lexes as a plain `IDENT` -- see `HCPsiParser.paramList`'s own header), `let`/`var`,
    // a `for` loop's own variable, a `try`/`catch`'s own caught-exception variable, and pattern
    // bindings from `match`/`if let` (every `IDENT` after a `VARIANT_PATTERN`'s own `{`, which
    // over-includes a `{ field: bind }` pattern's FIELD name alongside its real bind name -- safe
    // over-inclusion, same reasoning as this fn's own flow-insensitivity).
    private fun collectLocalNames(fnDecl: PsiElement): Set<String> {
        val names = mutableSetOf<String>()
        for (param in elementsOfType(fnDecl, HCElementTypes.PARAM)) {
            declaredName(param)?.let { names += it.text }
        }
        for (letStmt in elementsOfType(fnDecl, HCElementTypes.LET_STMT)) {
            declaredName(letStmt)?.let { names += it.text }
        }
        for (forStmt in elementsOfType(fnDecl, HCElementTypes.FOR_STMT)) {
            declaredName(forStmt)?.let { names += it.text }
        }
        for (catchClause in elementsOfType(fnDecl, HCElementTypes.CATCH_CLAUSE)) {
            declaredName(catchClause)?.let { names += it.text }
        }
        for (pattern in elementsOfType(fnDecl, HCElementTypes.VARIANT_PATTERN)) {
            val kids = directChildren(pattern)
            val braceIdx = kids.indexOfFirst { it.node?.elementType == HCTokenTypes.LBRACE }
            if (braceIdx < 0) continue
            for (kid in kids.drop(braceIdx + 1)) {
                if (kid.node?.elementType == HCTokenTypes.IDENT) names += kid.text
            }
        }
        for (lambda in elementsOfType(fnDecl, HCElementTypes.LAMBDA_EXPR)) {
            for (kid in directChildren(lambda)) {
                if (kid.node?.elementType == HCTokenTypes.IDENT) names += kid.text
            }
        }
        return names
    }

    private fun checkUndefinedReferences(file: PsiFile, holder: AnnotationHolder) {
        val topLevel = collectTopLevelValueNames(file) + ALWAYS_KNOWN_VALUE_NAMES
        for (fnDecl in elementsOfType(file, HCElementTypes.FN_DECL)) {
            val known = topLevel + collectLocalNames(fnDecl)
            for (ref in elementsOfType(fnDecl, HCElementTypes.REF_EXPR)) {
                val nameToken = directChildren(ref).firstOrNull { it.node?.elementType == HCTokenTypes.IDENT } ?: continue
                if (nameToken.text !in known) {
                    error(holder, nameToken, "unresolved reference '${nameToken.text}'")
                }
            }
        }
    }
}
